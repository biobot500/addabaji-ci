# -*- coding: utf-8 -*-
uiType = {'shortName': 'qt', 'moduleName': 'uiqt', 'longName': 'PyQt'}