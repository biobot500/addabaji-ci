# -*- coding: utf-8 -*-
from dabo.ui.dDataControlMixinBase import dDataControlMixinBase

class dDataControlMixin(dDataControlMixinBase):
	pass