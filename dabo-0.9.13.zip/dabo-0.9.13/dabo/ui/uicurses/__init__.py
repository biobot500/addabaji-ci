# -*- coding: utf-8 -*-
uiType = {'shortName': 'curses', 'moduleName': 'uicurses', 'longName': 'Curses'}