# -*- coding: utf-8 -*-
"""
Serialization machinery.

Objects
"""

from serialization import *
from xmlserializer import deserialize
