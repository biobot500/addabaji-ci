# -*- coding: utf-8 -*-
from dabo.dException import dException

class PropertyUpdateException(dException): pass
