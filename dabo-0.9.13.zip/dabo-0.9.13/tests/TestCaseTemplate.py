"""Test Case description goes here.

Rules for class functionality go here.

Class Requirements for proper behavior go here.

This file also provides the suite function.  The suite function will compile all of the test cases
defined in this file and load them into a test suite.  The function then returns the test suite.

If this file is run standalone, it will automatically run all of the test cases found in the file.
"""

import unittest

class TestCaseSample(unittest.TestCase):
	pass

if __name__ == "__main__":
	unittest.main()