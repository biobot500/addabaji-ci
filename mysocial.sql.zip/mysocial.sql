-- phpMyAdmin SQL Dump
-- version 2.11.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 09, 2014 at 06:46 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `mysocial`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) collate utf8_bin NOT NULL default '0',
  `ip_address` varchar(16) collate utf8_bin NOT NULL default '0',
  `user_agent` varchar(150) collate utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text collate utf8_bin NOT NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `ci_sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) NOT NULL,
  `status_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `comment` varchar(255) character set utf8 NOT NULL,
  `date` datetime NOT NULL,
  `banned` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `status_id`, `user_id`, `comment`, `date`, `banned`) VALUES
(0, 41, 1, 'hello world', '2013-12-15 21:48:47', 0),
(0, 41, 1, '123', '2013-12-27 19:56:27', 0),
(0, 41, 1, '321321', '2013-12-27 19:56:30', 0),
(0, 42, 1, 'f', '2013-12-27 19:57:45', 0),
(0, 26, 1, 'fdsfsa', '2013-12-27 19:57:53', 0),
(0, 43, 1, 'rewqrwq', '2013-12-27 19:58:01', 0),
(0, 46, 1, 'fdsa', '2013-12-27 19:58:20', 0),
(0, 46, 1, 'testsdsaaa', '2013-12-27 19:58:40', 0),
(0, 46, 1, 'tew', '2013-12-27 19:58:52', 0),
(0, 46, 0, '432', '2013-12-27 22:45:10', 0),
(0, 47, 1, 'hmmm  ???, ??? ??? ', '2013-12-28 17:51:12', 0),
(0, 47, 1, 'fdsa', '2013-12-28 17:51:29', 0),
(0, 47, 1, 'fsdafsa', '2013-12-28 17:51:36', 0),
(0, 47, 1, 'fdsafsa fds ', '2013-12-28 17:52:09', 0),
(0, 42, 1, 'dsadsadsasa ', '2013-12-28 17:52:22', 0),
(0, 47, 1, 'hehehehe  ফদসা ফদসা ', '2013-12-28 17:54:53', 0),
(0, 49, 1, 'trew ', '2014-01-01 19:37:04', 0),
(0, 49, 1, 'fdsadfdsa', '2014-01-01 19:37:26', 0),
(0, 49, 1, 'dsadsa', '2014-01-01 19:37:28', 0),
(0, 49, 1, 'fds', '2014-01-01 19:44:07', 0),
(0, 49, 1, 'hello profile', '2014-01-02 15:57:38', 0),
(0, 49, 1, 'test', '2014-01-06 08:14:09', 0),
(0, 51, 1, 'test', '2014-01-06 08:19:11', 0),
(0, 51, 1, 'hello world', '2014-01-06 08:20:03', 0),
(0, 1, 1, 'fdsfadsfas', '2014-01-06 08:31:52', 0),
(0, 51, 1, 'hello world', '2014-01-06 08:48:30', 0),
(0, 51, 1, 'hel', '2014-01-06 08:49:34', 0),
(0, 52, 1, 'welcome to addabaji.com', '2014-01-09 10:05:49', 0),
(0, 52, 2, 'dsadsada', '2014-01-09 12:53:29', 0),
(0, 52, 2, 'fdsafsa', '2014-01-09 12:56:33', 0),
(0, 52, 1, 'fgfs\n', '2014-01-09 13:30:09', 0),
(0, 52, 2, 'Check the address for typing errors such as ww.example.com instead of www.example.com Check the address for typing errors such as ww.example.com instead of www.example.com Check the address for typing errors such as ww.example.com instead of www.example.c', '2014-01-09 13:33:28', 0),
(0, 52, 2, 'Check the address for typing errors such as ww.example.com instead of www.example.com Check the address for typing errors such as ww.example.com instead of www.example.com Check the address for typing errors such as ww.example.com instead of www.example.c', '2014-01-09 13:33:38', 0),
(0, 52, 2, 'check', '2014-01-09 14:29:20', 0),
(0, 52, 2, 'check', '2014-01-09 14:30:29', 0),
(0, 52, 2, 'fdafdas', '2014-01-09 14:33:36', 0),
(0, 52, 2, 'fdsa', '2014-01-09 14:34:17', 0),
(0, 52, 2, 'dsa', '2014-01-09 14:36:10', 0),
(0, 52, 1, 'dsdsdsdsds', '2014-01-09 14:38:31', 0),
(0, 52, 1, 'ds', '2014-01-09 14:39:20', 0),
(0, 52, 2, 'dsadsa', '2014-01-09 14:41:34', 0),
(0, 52, 1, 'dsadas', '2014-01-09 14:42:02', 0),
(0, 52, 1, 's', '2014-01-09 14:42:54', 0),
(0, 52, 2, 'sasasasa', '2014-01-09 14:43:06', 0),
(0, 52, 2, 'fdsafasdfasd', '2014-01-09 14:44:10', 0),
(0, 52, 2, 'fdsa', '2014-01-09 14:45:48', 0),
(0, 52, 2, 'dsadsadas', '2014-01-09 14:49:37', 0),
(0, 52, 2, 'dsadsadsa', '2014-01-09 14:50:00', 0),
(0, 32, 2, 'mm,', '2014-01-09 15:13:38', 0);

-- --------------------------------------------------------

--
-- Table structure for table `example_1`
--

CREATE TABLE `example_1` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(250) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=178 ;

--
-- Dumping data for table `example_1`
--

INSERT INTO `example_1` (`id`, `url`) VALUES
(172, 'c360-9.jpg'),
(176, 'b7b8-18.jpg'),
(177, '3fd6-21.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `example_2`
--

CREATE TABLE `example_2` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(250) default NULL,
  `priority` int(11) default NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `example_2`
--

INSERT INTO `example_2` (`id`, `url`, `priority`, `user_id`) VALUES
(2, '0ea96-blogdaybanner.jpg', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `example_3`
--

CREATE TABLE `example_3` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(250) default NULL,
  `category_id` int(11) default NULL,
  `priority` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=180 ;

--
-- Dumping data for table `example_3`
--

INSERT INTO `example_3` (`id`, `url`, `category_id`, `priority`) VALUES
(172, 'a48d-88.jpg', 22, NULL),
(173, '5e32-89.jpg', 22, NULL),
(174, '7628-90.jpg', 22, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `example_4`
--

CREATE TABLE `example_4` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `url` varchar(250) default NULL,
  `priority` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=182 ;

--
-- Dumping data for table `example_4`
--

INSERT INTO `example_4` (`id`, `title`, `url`, `priority`) VALUES
(172, 'My house!', 'eb4f-51.jpg', 1),
(173, 'Some flowers', 'ac84-52.jpg', 3),
(176, 'My garden!', '7ad8-63.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL auto_increment,
  `ip_address` varchar(40) collate utf8_bin NOT NULL,
  `login` varchar(50) collate utf8_bin NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=18 ;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `ip_address`, `login`, `time`) VALUES
(14, '127.0.0.1', 'rhythm.shahriar.bd@gmail.com', '2014-01-09 17:36:32'),
(13, '127.0.0.1', 'rhythm.shahriar.bd@gmail.com', '2014-01-09 17:36:27'),
(15, '127.0.0.1', 'rhythm.shahriar.bd@gmail.com', '2014-01-09 17:36:34'),
(16, '127.0.0.1', 'rhythm.shahriar.bd@gmail.com', '2014-01-09 17:36:38'),
(17, '127.0.0.1', 'rhythm.shahriar.bd@gmail.com', '2014-01-09 17:36:41');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` bigint(20) NOT NULL auto_increment,
  `sender_id` bigint(20) NOT NULL,
  `receiver_id` bigint(20) NOT NULL,
  `body` varchar(200) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `message`
--


-- --------------------------------------------------------

--
-- Table structure for table `msg_messages`
--

CREATE TABLE `msg_messages` (
  `id` int(11) NOT NULL auto_increment,
  `thread_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `priority` int(2) NOT NULL default '0',
  `sender_id` int(11) NOT NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `msg_messages`
--

INSERT INTO `msg_messages` (`id`, `thread_id`, `body`, `priority`, `sender_id`, `cdate`) VALUES
(1, 1, 'hello', 1, 1, '2014-01-09 17:31:14'),
(2, 1, 'hi', 1, 2, '2014-01-09 17:42:03'),
(3, 2, 'test', 1, 1, '2014-01-09 17:52:03'),
(4, 3, 'test2', 1, 1, '2014-01-09 17:52:41'),
(5, 4, 'dsafsafas', 1, 2, '2014-01-09 18:00:57'),
(6, 5, 'fdsjfdaslkflksa', 1, 2, '2014-01-09 18:09:04'),
(7, 6, 'dfsafs', 1, 2, '2014-01-09 18:12:27'),
(8, 6, 'what is that????', 1, 1, '2014-01-09 18:12:51'),
(9, 6, 'ok', 1, 2, '2014-01-09 18:21:04'),
(10, 6, 'lsa', 1, 1, '2014-01-09 18:21:50'),
(11, 7, 'das', 1, 1, '2014-01-09 18:24:40'),
(12, 7, '321312312', 1, 2, '2014-01-09 18:25:08'),
(13, 8, '312312', 1, 2, '2014-01-09 18:26:14'),
(14, 8, 'dsadsadsada', 1, 1, '2014-01-09 18:26:49'),
(15, 9, 'dsa', 1, 2, '2014-01-09 18:27:32'),
(16, 10, 'wsadas', 1, 2, '2014-01-09 18:27:48'),
(17, 10, 'erwqrewreqwrwqrq', 1, 1, '2014-01-09 18:28:26'),
(18, 11, '21312312312321', 1, 1, '2014-01-09 18:29:37'),
(19, 11, 'rewq', 1, 2, '2014-01-09 18:30:13'),
(20, 12, '321321', 1, 2, '2014-01-09 18:31:49'),
(21, 12, 'dsadsads', 1, 1, '2014-01-09 18:32:41'),
(22, 13, 'dskf;lsakf;lask;flsadfsdsdfdsafasdfsa', 1, 1, '2014-01-09 18:34:23'),
(23, 14, 'DSADSADSADSADSA', 1, 2, '2014-01-09 18:36:23'),
(24, 14, 'fdsafdsafa', 1, 2, '2014-01-09 18:37:46'),
(25, 14, 'fdsafdslfk;sda;flslfsa;lf;a', 1, 2, '2014-01-09 18:38:25'),
(26, 14, 'fdsafdsafdsafsa', 1, 2, '2014-01-09 18:38:50'),
(27, 14, 'fdsafdsafdasfsa', 1, 2, '2014-01-09 18:39:14'),
(28, 15, 'fdsfasfsa', 1, 2, '2014-01-09 18:40:01'),
(29, 15, 'hi', 1, 2, '2014-01-09 18:40:44'),
(30, 15, 'fas', 1, 2, '2014-01-09 18:43:38'),
(31, 15, 'fsadfsadfsd', 1, 1, '2014-01-09 18:45:39'),
(32, 15, 'dfasdfsa', 1, 2, '2014-01-09 18:46:29');

-- --------------------------------------------------------

--
-- Table structure for table `msg_participants`
--

CREATE TABLE `msg_participants` (
  `user_id` int(11) NOT NULL,
  `thread_id` int(11) NOT NULL,
  `cdate` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`user_id`,`thread_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `msg_participants`
--

INSERT INTO `msg_participants` (`user_id`, `thread_id`, `cdate`) VALUES
(1, 1, '2014-01-09 17:31:14'),
(2, 1, '2014-01-09 17:31:14'),
(1, 2, '2014-01-09 17:52:03'),
(2, 2, '2014-01-09 17:52:03'),
(1, 3, '2014-01-09 17:52:41'),
(2, 3, '2014-01-09 17:52:41'),
(2, 4, '2014-01-09 18:00:57'),
(1, 4, '2014-01-09 18:00:57'),
(2, 5, '2014-01-09 18:09:04'),
(1, 5, '2014-01-09 18:09:04'),
(2, 6, '2014-01-09 18:12:27'),
(1, 6, '2014-01-09 18:12:27'),
(1, 7, '2014-01-09 18:24:40'),
(2, 7, '2014-01-09 18:24:40'),
(2, 8, '2014-01-09 18:26:14'),
(1, 8, '2014-01-09 18:26:14'),
(2, 9, '2014-01-09 18:27:32'),
(2, 10, '2014-01-09 18:27:48'),
(1, 10, '2014-01-09 18:27:48'),
(1, 11, '2014-01-09 18:29:37'),
(2, 11, '2014-01-09 18:29:37'),
(2, 12, '2014-01-09 18:31:49'),
(1, 12, '2014-01-09 18:31:49'),
(1, 13, '2014-01-09 18:34:23'),
(2, 13, '2014-01-09 18:34:23'),
(2, 14, '2014-01-09 18:36:23'),
(1, 14, '2014-01-09 18:36:23'),
(2, 15, '2014-01-09 18:40:01'),
(1, 15, '2014-01-09 18:40:01');

-- --------------------------------------------------------

--
-- Table structure for table `msg_status`
--

CREATE TABLE `msg_status` (
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY  (`message_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `msg_status`
--

INSERT INTO `msg_status` (`message_id`, `user_id`, `status`) VALUES
(1, 1, 1),
(1, 2, 0),
(2, 2, 1),
(2, 1, 0),
(3, 1, 1),
(3, 2, 0),
(4, 1, 1),
(4, 2, 0),
(5, 2, 1),
(5, 1, 0),
(6, 2, 1),
(6, 1, 0),
(7, 2, 1),
(7, 1, 0),
(8, 1, 1),
(8, 2, 0),
(9, 2, 1),
(9, 1, 0),
(10, 1, 1),
(10, 2, 0),
(11, 1, 1),
(11, 2, 0),
(12, 2, 1),
(12, 1, 0),
(13, 2, 1),
(13, 1, 0),
(14, 1, 1),
(14, 2, 0),
(16, 2, 1),
(16, 1, 0),
(17, 1, 1),
(17, 2, 0),
(18, 1, 1),
(18, 2, 0),
(19, 2, 1),
(19, 1, 0),
(20, 2, 1),
(20, 1, 0),
(21, 1, 1),
(21, 2, 0),
(22, 1, 1),
(22, 2, 0),
(23, 2, 1),
(23, 1, 0),
(24, 2, 1),
(24, 1, 0),
(25, 2, 1),
(25, 1, 0),
(26, 2, 1),
(26, 1, 0),
(27, 2, 1),
(27, 1, 0),
(28, 2, 1),
(28, 1, 0),
(29, 2, 1),
(29, 1, 0),
(30, 2, 1),
(30, 1, 0),
(31, 1, 1),
(31, 2, 0),
(32, 2, 1),
(32, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `msg_threads`
--

CREATE TABLE `msg_threads` (
  `id` int(11) NOT NULL auto_increment,
  `subject` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `msg_threads`
--

INSERT INTO `msg_threads` (`id`, `subject`) VALUES
(1, ':D'),
(2, 'test'),
(3, 'test2'),
(4, 'fdasf'),
(5, 'hi'),
(6, 'fdsafdsfsa'),
(7, '123'),
(8, 'dfsa'),
(9, 'dsadsasaaasa'),
(10, '2132'),
(11, '3213213'),
(12, '12312'),
(13, 'dmaskdsalkd'),
(14, 'dsaDSDSA'),
(15, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `obj_id` bigint(20) NOT NULL,
  `msg` varchar(200) NOT NULL,
  `type` varchar(100) NOT NULL,
  `new` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `obj_id`, `msg`, `type`, `new`, `date`) VALUES
(1, 1, 0, 'You have a new message', 'message', 0, '2014-01-09 12:36:23'),
(2, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:37:46'),
(3, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:38:25'),
(4, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:38:50'),
(5, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:39:14'),
(6, 1, 0, 'You have a new message', 'message', 0, '2014-01-09 12:40:01'),
(7, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:40:44'),
(8, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:43:38'),
(9, 2, 0, 'You have a new message', 'message', 0, '2014-01-09 12:45:39'),
(10, 1, 0, 'You have a new message', 'message', 0, '2014-01-09 12:46:29'),
(11, 2, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 12:53:29'),
(12, 2, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 12:56:33'),
(13, 1, 52, 'Rhythm has commented on your post', 'html,js', 0, '2014-01-09 13:30:09'),
(14, 2, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 13:33:28'),
(15, 2, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 13:33:38'),
(16, 1, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 14:29:20'),
(17, 1, 52, 'Nitu has replied on post', 'html,js', 0, '2014-01-09 14:29:20'),
(18, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:30:29'),
(19, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:30:29'),
(20, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:33:36'),
(21, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:33:36'),
(22, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:34:17'),
(23, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:34:17'),
(24, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:36:10'),
(25, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:36:10'),
(26, 1, 52, 'Rhythm has commented on your post', 'html,js', 0, '2014-01-09 14:38:31'),
(27, 1, 52, 'Rhythm has commented on your post', 'comment', 0, '2014-01-09 14:39:20'),
(28, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:41:34'),
(29, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:41:34'),
(30, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:41:34'),
(31, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:41:34'),
(32, 2, 52, 'Rhythm has commented on your post', 'comment', 0, '2014-01-09 14:42:02'),
(33, 2, 52, 'Rhythm has commented on your post', 'comment', 0, '2014-01-09 14:42:54'),
(34, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(35, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(36, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(37, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(38, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(39, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:43:06'),
(40, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(41, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(42, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(43, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(44, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(45, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:44:10'),
(46, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(47, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(48, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(49, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(50, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(51, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:45:48'),
(52, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:49:37'),
(53, 1, 52, 'Nitu has replied on post', 'comment', 0, '2014-01-09 14:50:00'),
(54, 1, 32, 'Nitu has commented on your post', 'comment', 0, '2014-01-09 15:13:38');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` bigint(20) NOT NULL auto_increment,
  `user_id` bigint(20) NOT NULL,
  `status` mediumtext character set utf8 NOT NULL,
  `type` enum('text','photo','video') NOT NULL,
  `date` datetime NOT NULL,
  `banned` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `user_id`, `status`, `type`, `date`, `banned`) VALUES
(1, 1, 'fdsafdasfsdafdsa', 'text', '2013-11-28 12:17:48', 0),
(2, 1, 'fdsafdasfsdafdsa', 'text', '2013-11-28 12:18:30', 0),
(3, 1, 'fdsafdasfsdafdsa', 'text', '2013-11-28 12:18:41', 0),
(4, 1, 'dsadas', 'text', '2013-12-01 16:45:50', 0),
(5, 1, 'dsadas', 'text', '2013-12-01 17:00:35', 0),
(6, 1, 'dsadas111', 'text', '2013-12-01 17:00:38', 0),
(7, 1, 'dsadas111', 'text', '2013-12-01 17:00:39', 0),
(8, 1, 'dsadas111', 'text', '2013-12-01 17:00:40', 0),
(9, 1, 'dsadas111', 'text', '2013-12-01 17:00:40', 0),
(10, 1, 'dsadas111', 'text', '2013-12-01 17:00:40', 0),
(11, 1, 'dsadas111', 'text', '2013-12-01 17:00:53', 0),
(12, 1, 'dsa', 'text', '2013-12-01 17:01:22', 0),
(13, 1, 'dsa', 'text', '2013-12-01 17:01:31', 0),
(14, 1, 'dsa1', 'text', '2013-12-01 17:02:06', 0),
(15, 1, '1', 'text', '2013-12-01 17:02:21', 0),
(16, 1, '2', 'text', '2013-12-01 17:03:04', 0),
(17, 1, 'sasasa', 'text', '2013-12-01 17:03:23', 0),
(18, 1, 'sasasa1', 'text', '2013-12-01 17:03:24', 0),
(19, 1, 'sasasa132131', 'text', '2013-12-01 17:03:26', 0),
(20, 1, 'dasdsadas', 'text', '2013-12-01 17:03:30', 0),
(21, 1, 'dsadsadsadsa', 'text', '2013-12-01 17:03:35', 0),
(22, 1, 'dsadsadsadsa lfldls fdsa fdsafdsa', 'text', '2013-12-01 17:03:57', 0),
(23, 1, '2', 'text', '2013-12-01 17:04:37', 0),
(24, 1, '2321321', 'text', '2013-12-01 17:04:40', 0),
(25, 1, 'hello world', 'text', '2013-12-01 17:06:05', 0),
(26, 1, 'dsadas', 'text', '2013-12-01 17:06:47', 0),
(27, 1, 'fdsa', 'text', '2013-12-01 17:12:00', 0),
(28, 1, 'fdsadasddddddddddddddddddasdsa', 'text', '2013-12-01 17:14:00', 0),
(29, 1, 'dsa', 'text', '2013-12-01 17:20:08', 0),
(30, 1, 'dsa', 'text', '2013-12-01 17:20:10', 0),
(31, 1, 'dsa1', 'text', '2013-12-01 17:20:12', 0),
(32, 1, 'dsa12312', 'text', '2013-12-01 17:20:13', 0),
(33, 1, 'dsa12312', 'text', '2013-12-01 17:20:15', 0),
(34, 1, 'dsa12312 fdsa dsa', 'text', '2013-12-01 17:20:44', 0),
(35, 1, 'dsa12312 fdsa dsa', 'text', '2013-12-01 17:20:45', 0),
(36, 1, 'dsada da das dsa', 'text', '2013-12-01 17:20:49', 0),
(37, 1, 'dsasasa', 'text', '2013-12-01 17:24:34', 0),
(38, 1, 'fdsfdsfds', 'text', '2013-12-01 17:25:51', 0),
(39, 1, 'fdsfdsfdsfds', 'text', '2013-12-01 17:25:54', 0),
(40, 1, 'fdsfsafas', 'text', '2013-12-01 17:28:25', 0),
(41, 1, 'sddsdsds', 'text', '2013-12-01 17:42:28', 0),
(42, 1, 'fdsa', 'text', '2013-12-27 19:06:16', 0),
(43, 1, 'fdsa', 'text', '2013-12-27 19:06:17', 0),
(44, 1, 'fdsafdsa', 'text', '2013-12-27 19:58:06', 0),
(45, 1, 'fdsafdsa321', 'text', '2013-12-27 19:58:11', 0),
(46, 1, 'fdsafdsa321321321', 'text', '2013-12-27 19:58:16', 0),
(47, 1, 'আমি ভাত খাব, আমি এক্তা খাদক !!! হা হা হা হা ', 'text', '2013-12-28 16:56:11', 0),
(48, 1, 'dfa', 'text', '2014-01-01 12:47:18', 0),
(49, 1, 'dfa', 'text', '2014-01-01 12:47:40', 0),
(50, 1, 'blablabla', 'text', '2014-01-06 08:17:58', 0),
(51, 1, 'blabla2', 'text', '2014-01-06 08:19:03', 0),
(52, 2, 'hello world, i am new to this site', 'text', '2014-01-09 10:05:02', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(50) collate utf8_bin NOT NULL,
  `password` varchar(255) collate utf8_bin NOT NULL,
  `email` varchar(100) collate utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL default '1',
  `banned` tinyint(1) NOT NULL default '0',
  `ban_reason` varchar(255) collate utf8_bin default NULL,
  `new_password_key` varchar(50) collate utf8_bin default NULL,
  `new_password_requested` datetime default NULL,
  `new_email` varchar(100) collate utf8_bin default NULL,
  `new_email_key` varchar(50) collate utf8_bin default NULL,
  `last_ip` varchar(40) collate utf8_bin NOT NULL,
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `first_name` varchar(50) collate utf8_bin NOT NULL,
  `last_name` varchar(50) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `first_name`, `last_name`) VALUES
(1, 'rhythm', '$P$BlarGb0DMskWjRenP5BivKwR2br41D.', 'rhythm.shahriar.bd@gmail.com', 1, 0, NULL, NULL, NULL, NULL, 'eae71c41dc00f1abbc866cc0103af16e', '127.0.0.1', '2014-01-09 13:27:38', '2013-11-22 22:16:00', '2014-01-09 19:27:38', 'Rhythm', 'Shahriar'),
(2, 'nitu', '$P$BhtAFuxKMG1H6OCFmWDwWY6yg5eWAd/', 'nitu@technoturbine.com', 1, 0, NULL, NULL, NULL, NULL, '3ba37c52e6ebba31e4ef888919fb5d21', '127.0.0.1', '2014-01-09 11:44:48', '2014-01-09 09:54:12', '2014-01-09 17:44:48', 'Nitu', 'Shahriar');

-- --------------------------------------------------------

--
-- Table structure for table `user_autologin`
--

CREATE TABLE `user_autologin` (
  `key_id` char(32) collate utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `user_agent` varchar(150) collate utf8_bin NOT NULL,
  `last_ip` varchar(40) collate utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`key_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_autologin`
--

INSERT INTO `user_autologin` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`) VALUES
('ed68b1e1e95ad91e64c1813be248edb5', 1, 'Mozilla/5.0 (Windows NT 6.1; rv:26.0) Gecko/20100101 Firefox/26.0', '127.0.0.1', '2013-12-28 05:00:22');

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) collate utf8_bin default NULL,
  `website` varchar(255) collate utf8_bin default NULL,
  `name` varchar(100) character set utf8 NOT NULL,
  `age` varchar(100) character set utf8 NOT NULL,
  `location` varchar(100) character set utf8 NOT NULL,
  `gender` varchar(50) collate utf8_bin NOT NULL,
  `occu` varchar(100) character set utf8 NOT NULL,
  `avatar` varchar(200) collate utf8_bin NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_profiles`
--

INSERT INTO `user_profiles` (`id`, `user_id`, `country`, `website`, `name`, `age`, `location`, `gender`, `occu`, `avatar`) VALUES
(1, 1, NULL, NULL, 'Rhythm Shahriar', '২৭', 'গ্রীন রোড , ঢাকা , বাংলাদেশ ', 'male', 'Software Engineer', 'profile_pic/technoturbine_logo2.png'),
(2, 2, NULL, NULL, 'Nitu Shahriar', '13', 'Green road, dhaka, bangladesh', 'female', 'Student', 'profile_pic/hack-the-planet.jpg');
